# Perla tutorial source bundle

Contains the installable Perla package and the complete Starbucks case.
Use the accompanying tutorial's installation and execution instructions.
Python 3.11+ and Git are required for installation with the EDSL extra.
